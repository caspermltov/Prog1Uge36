from machine import Pin
from time import sleep

RED_PIN = 26
led1 = Pin(RED_PIN, Pin.OUT)

YELLOW_PIN = 12
led2 = Pin(YELLOW_PIN, Pin.OUT)

GREEN_PIN = 13
led3 = Pin(GREEN_PIN, Pin.OUT)


"""
#led1.on()
while True:
    print("All LED's ON!")
    led1.on()
    led2.off() #LED2 er inverteret
    led3.on()
    sleep(1)
    print("All LED's OFF!")
    led1.off()
    led2.on() #LED2 er inverteret
    led3.off()
    sleep(1)
"""
while True:
    x = 1
    y = 0.1
    led1.on()
    sleep(y)
    led2.off()
    sleep(y)#LED2 er inverteret
    led3.on()
    sleep(y)
    led1.off()
    sleep(y)
    led2.on() #LED2 er inverteret
    sleep(y)
    led3.off()
    sleep(x)
    
    led3.on()
    sleep(y)
    led2.off()
    sleep(y)#LED2 er inverteret
    led1.on()
    sleep(y)
    led3.off()
    sleep(y)
    led2.on() #LED2 er inverteret
    sleep(y)
    led1.off()
    sleep(x)
    
    led1.on()
    led2.off() #LED2 er inverteret
    led3.on()
    sleep(x)
    led1.off()
    led2.on() #LED2 er inverteret
    led3.off()
    sleep(x)
    led1.on()
    led2.off() #LED2 er inverteret
    led3.on()
    sleep(x)
    led1.off()
    led2.on() #LED2 er inverteret
    led3.off()
    sleep(x)
    led1.on()
    led2.off() #LED2 er inverteret
    led3.on()
    sleep(x)
    led1.off()
    led2.on() #LED2 er inverteret
    led3.off()
    sleep(x)