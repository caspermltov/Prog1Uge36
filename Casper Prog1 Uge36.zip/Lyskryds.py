from machine import Pin
from time import sleep

RED_PIN = 26
led1 = Pin(RED_PIN, Pin.OUT)

YELLOW_PIN = 12
led2 = Pin(YELLOW_PIN, Pin.OUT)

GREEN_PIN = 13
led3 = Pin(GREEN_PIN, Pin.OUT)

led1.on()
led2.on()
led3.off()

while True:
    #rødt lys
    led1.on()#rød on
    led2.on()#gul off
    sleep(3)
    
    #gul+rød
    led2.off()#gul on
    sleep(2)
    
    #grøn
    led1.off()#rød off
    led2.on()#gul off
    led3.on()#grøn on
    sleep(3)
    
    #gul
    led2.off()#gul on
    led3.off()#grøn off
    sleep(2)

    
    
#Jeg endte med 0.125 sek interval for at jeg ikke kunne se led'en blinke