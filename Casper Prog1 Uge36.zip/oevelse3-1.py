"""

Traceback (most recent call last):
File
"c:\users\kevin\documents\kea\micropython\code\oevelser\o
evelse3.py", line 13, in <module>
print("Vi kan transportere", samlet_bil_kapacitet, "personer i
dag.")
NameError: name 'samlet_bil_kapacitet' is not defined

"""

Fejlen ligger på linje 7. enten skal der sættes en \n ind for
at lave linjeskift, og ellers skal et stå på samme linje, for
at Python kan finde ud af at printe teksten i Shell.