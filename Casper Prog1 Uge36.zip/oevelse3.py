#Laver en variabel med datatypen integer
biler = 100

#Laver en variabel med datatypen float
plads_i_en_bil = 4.0

#Laver en variabel med datatypen integer
førere = 30

#Laver en variabel med datatypen integer
passagerer = 90

#Laver en variabel med datatypen integer
biler_ude_af_drift = biler - førere

#Laver en variabel med datatypen integer
biler_i_kørsel = førere

#Laver en variabel med datatypen float
samlet_bil_kapacitet = biler_i_kørsel * plads_i_en_bil

#Laver en variabel med datatypen float
gennemsnit_af_passagerer_per_bil = passagerer / biler_i_kørsel

#skriver i shell hvor mange biler der er til rådighed i dag
print("Der er", biler, " biler til rådighed.")

#skriver i shell hvor mange førere der er til rådighed dag
print("Der er kun", førere, "førere til rådighed.")

#skriver i shell hvor mange tomme biler der er i dag
print("Der vil være", biler_ude_af_drift, "tomme biler i dag.")

#skriver i shell hvor mange personer der kan transporteres i dag
print("Vi kan transportere", samlet_bil_kapacitet, "personer i dag.")

#skriver i shell hvor mange passagere der skal transporteres i dag
print("Vi har", passagerer, "passagerer i dag.")

#skriver i shell hvor mange der i gennemsnit skal sidde i hver bil
print("Vi skal cirka putte", gennemsnit_af_passagerer_per_bil, "i hver bil.")