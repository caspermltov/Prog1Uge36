from machine import Pin
from time import sleep

pb1 = Pin(4, Pin.IN)
led1 = Pin(26, Pin.OUT)

previous_state = 1
counter = 0

while True:
    print("Antal tryk på knappen:", counter)
    current_state = pb1.value()
    
    #print("Knap værdi: ", pb1.value())
    sleep(0.1)
    if previous_state == 1 and current_state == 0:
            led1.value(not led1.value())
            counter += 1
    
    previous_state = current_state

#Det er ikke perfekt, fordi at jeg mangler en før/efter-værdi på knappen