from machine import Pin
from time import sleep

pb1 = Pin(4, Pin.IN)
led1 = Pin(26, Pin.OUT)

while True:
    first = pb1.value()
    sleep(0.01)
    second = pb1.value()
    
    if first == 1 and second == 0:
        print("Knapper er trykket")
        led1.value(not led1.value())
        
    if first == 0 and second == 1:
        print("Knappen er sluppet")